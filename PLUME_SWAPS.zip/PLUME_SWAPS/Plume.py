import time
import random
import threading
from web3 import Web3
from rich.console import Console
from rich.text import Text
from rich.prompt import Prompt

console = Console()

def print_banner():
    banner = Text("""
.....................................................................
.......................................**............#...............
......................................*++=+.++********...............
....................................#+++++.+++********+..............
.................................--.......:+++++++*++****............
..............................-*+......-...=++++++++++****.....#=....
............................-+++-....:--...++++++++++++****++***:....
..........................=++++++-.......=+++++++++++*++*******:.....
........................:+++++++++.+#++*+++++++++++++*********.......
.......................+++++*+++.......**++++++++++++++******........
......................-+++++=.-++++++++:*++++++++++++++****:...:.....
..................--:.=+#++*........-*++++*+++++++++++++++***...=....
...................-=*++#*+.............=+++*++++++++++++++******....
.............................-**-..........+++++++++++++++++*****....
..................-.*#-..:.+######*.........-*+++++++++*++++****+....
..................#++###.:.#..#####..........++++++++++**++*****:....
..................:#####.-.########..........++++++++++*********.....
.........:+*+=-:....*+-:....-###*...........+++++++++++*******#......
.........+++++++++.............-..........=++++++++++++*******.......
........*+++*++++................:.....=*+++++++++++++*******........
.......-++++++++=.............=.....++++++++++++++++*******-.........
.......++++++++++-..........:...*....*++++++++++++++*****#...........
.......=++++++++........::....+++*....++++++++++++*****+..-+.........
.......=++++++=::=*+:......-*++++#....*++++++********......+*=.......
.......=++=.......+*+==+++++++++*....*+******=.=.......:=.....+......
.......=+....-=#*+*=::--*#**+++*:...-+++++*:.:.................+.....
.......:......-.-+:...:-:::--=+....-==-::......................:-....
................-:.:++---=+=....-...............................=....
....................:=:::::::......................-.............*...
....................-....-.........................#..............+..
....................-...-..........................-..............-:.
...................:....#...........................-..............-.
...................:....+...........................+..............=.
.......................:............................-..........::-..-
.....................#+#............................::..:=*#*****#.:=

               ██████  ██      ██    ██ ███    ███ ███████ 
              ██    ██ ██      ██    ██ ████  ████ ██      
              ██    ██ ██      ██    ██ ██ ████ ██ █████   
              ███████  ██      ██    ██ ██  ██  ██ ██      
              ██       ██████  ████████ ██  ██  ██ ███████
                                        
                        [PLUME FUCKER BOT v1.0]

""", style="#D13300")
    console.print(banner)

def get_input_with_default(prompt_text, default_value, cast_type=str):
    prompt = f"[grey85]{prompt_text} [dim]({default_value})[/]: [/grey85]"
    raw = Prompt.ask(prompt, default=str(default_value))
    try:
        return cast_type(raw)
    except Exception:
        console.print(f"[red]❌ Неверный ввод, используется значение по умолчанию: {default_value}[/red]")
        return default_value

print_banner()
console.print("\n[grey54]=== НАСТРОЙКА ===[/]\n")
use_proxies = None
while use_proxies not in ("y", "n"):
    use_proxies = Prompt.ask("[grey85]Использовать прокси? (y/n):[/]").strip().lower()

mode = None
while mode not in ("1", "2"):
    mode = Prompt.ask("[grey85]Выберите режим: 1 — однопоточный, 2 — многопоточный:[/]").strip()

private_keys_file = "private_keys.txt"

if use_proxies == "y":
    proxy_file = Prompt.ask("[grey85]Файл с прокси[/]", default="proxy.txt")
else:
    proxy_file = None

swap_count = get_input_with_default("🔁 Количество свапов на кошелек", 400, int)
amount_min = get_input_with_default("💸 Минимальная сумма свапа", 0.0095, float)
amount_max = get_input_with_default("💸 Максимальная сумма свапа", 0.105, float)
delay_between_tx_min = get_input_with_default("⏱️ Минимальная задержка между транзакциями (сек)", 5, int)
delay_between_tx_max = get_input_with_default("⏱️ Максимальная задержка между транзакциями (сек)", 20, int)
afk_chance = get_input_with_default("🙈 Шанс пропуска (AFK) (0-1)", 0.05, float)
afk_delay_min = get_input_with_default("😴 Минимальная задержка AFK (сек)", 5, int)
afk_delay_max = get_input_with_default("😴 Максимальная задержка AFK (сек)", 30, int)
start_delay = get_input_with_default("⏳ Задержка перед стартом (сек)", 5, int)

max_threads = get_input_with_default("🧵 Максимум потоков (многопоточный режим)", 6, int)
min_thread_delay = get_input_with_default("🕒 Минимальная задержка между стартами потоков (сек)", 1, int)
max_thread_delay = get_input_with_default("🕒 Максимальная задержка между стартами потоков (сек)", 5, int)

console.print(f"📥 Загружаем приватные ключи из {private_keys_file}...", style="yellow")
with open(private_keys_file, "r") as f:
    private_keys = [line.strip() for line in f if line.strip()]

if use_proxies == "y":
    console.print(f"📥 Загружаем прокси из {proxy_file}...", style="yellow")
    with open(proxy_file, "r") as f:
        proxies = [line.strip() for line in f if line.strip()]

    if len(proxies) != len(private_keys):
        raise ValueError("❌ Количество прокси должно совпадать с количеством приватников!")

PLUME_RPC = "https://rpc.plume.org"
WRAP_CONTRACT_ADDRESS = Web3.to_checksum_address("0xEa237441c92CAe6FC17Caaf9a7acB3f953be4bd1")
WRAP_ABI = [
    {
        "inputs": [],
        "name": "deposit",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
    }
]

def send_wrap(web3, wrap_contract, wallet_address, private_key, amount):
    nonce = web3.eth.get_transaction_count(wallet_address)
    gas_price = web3.eth.gas_price

    txn = wrap_contract.functions.deposit().build_transaction({
        'from': wallet_address,
        'value': web3.to_wei(amount, 'ether'),
        'nonce': nonce,
        'gas': 100000,
        'gasPrice': gas_price
    })

    signed_txn = web3.eth.account.sign_transaction(txn, private_key=private_key)
    tx_hash = web3.eth.send_raw_transaction(signed_txn.raw_transaction)
    return tx_hash.hex()

def worker(index):
    PRIVATE_KEY = private_keys[index]

    if use_proxies == "y":
        proxy = proxies[index]
        try:
            login, password, ip, port = proxy.split(":")
        except Exception:
            console.print(f"[{index+1}] ❌ Ошибка в формате прокси: {proxy}", style="red")
            return

        proxy_url = f"http://{login}:{password}@{ip}:{port}"

        web3 = Web3(Web3.HTTPProvider(PLUME_RPC, request_kwargs={
            "proxies": {
                "http": proxy_url,
                "https": proxy_url
            }
        }))
        console.print(f"[{index+1}] 🌐 Используется прокси {ip}:{port}", style="green")
    else:
        web3 = Web3(Web3.HTTPProvider(PLUME_RPC))
        console.print(f"[{index+1}] 🔓 Используется без прокси", style="yellow")

    try:
        account = web3.eth.account.from_key(PRIVATE_KEY)
        wallet_address = account.address
        console.print(f"\n==========================", style="bold cyan")
        console.print(f"🚀 Кошелек {index + 1}/{len(private_keys)}", style="bold green")
        console.print(f"🔑 Адрес: {wallet_address}", style="bold yellow")

        wrap_contract = web3.eth.contract(address=WRAP_CONTRACT_ADDRESS, abi=WRAP_ABI)

        balance = web3.eth.get_balance(wallet_address)
        console.print(f"💰 Баланс: {web3.from_wei(balance, 'ether')} PLUME", style="magenta")

        console.print(f"⏳ Ожидание {start_delay} сек перед началом...", style="dim")
        time.sleep(start_delay)

        for i in range(swap_count):
            try:
                amount = round(random.uniform(amount_min, amount_max), 6)
                console.print(f"[{index+1}] 🔁 Swap #{i+1} на сумму {amount} PLUME")

                if random.random() < afk_chance:
                    console.print(f"[{index+1}] 🙈 Пропуск (AFK)")
                    delay = random.uniform(afk_delay_min, afk_delay_max)
                    console.print(f"[{index+1}] 🕒 Ждем {round(delay)} сек...")
                    time.sleep(delay)
                    continue

                tx_hash = send_wrap(web3, wrap_contract, wallet_address, PRIVATE_KEY, amount)
                console.print(f"[{index+1}] ✅ Wrap отправлен: {tx_hash}")

                console.print(f"[{index+1}] ⏳ Ожидание подтверждения...")
                receipt = web3.eth.wait_for_transaction_receipt(tx_hash, timeout=90)
                console.print(f"[{index+1}] ✅ Подтверждено в блоке {receipt.blockNumber}")

            except Exception as e:
                console.print(f"[{index+1}] ❌ Ошибка: {e}", style="red")

            delay = random.uniform(delay_between_tx_min, delay_between_tx_max)
            console.print(f"[{index+1}] 😴 Пауза {round(delay)} сек перед следующей попыткой")
            time.sleep(delay)

    except Exception as e:
        console.print(f"[{index+1}] ❌ Ошибка с ключом: {e}", style="red")

def start_worker_with_delay(index, delay):
    time.sleep(delay)
    worker(index)

if __name__ == "__main__":
    if mode == "2":
        threads = []
        total_delay = 0

        for i in range(len(private_keys)):
            delay = random.uniform(min_thread_delay, max_thread_delay)
            total_delay += delay
            t = threading.Thread(target=start_worker_with_delay, args=(i, total_delay))
            t.start()
            threads.append(t)

            while threading.active_count() > max_threads:
                time.sleep(1)

        for t in threads:
            t.join()
    else:
        for i in range(len(private_keys)):
            worker(i)
